-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2020 at 03:57 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cr13_rebecca_schedler_bigevents`
--

-- --------------------------------------------------------

--
-- Table structure for table `event_info`
--

CREATE TABLE `event_info` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capacity` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phonenumber` bigint(20) NOT NULL,
  `location_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `eventtype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `event_info`
--

INSERT INTO `event_info` (`id`, `name`, `description`, `date`, `time`, `image`, `event_url`, `capacity`, `email`, `phonenumber`, `location_name`, `address`, `eventtype`) VALUES
(1, 'Live Music Concert', 'It\'s the concert that you have been waiting for. blablajfh fdsskf skdfhsugsdg ghkdajghskdfj sidfuaoiguaksg usdoiguso iusdjkdjnsdnfsjf sdfusdfakdsfklsfjlkd saidufs.\r\nsdfuosidfnvcnxclkyj aidsu sajhdk', '2020-09-09', '19:00:00', 'https://news.imz.at/imzfiles/636177-slideshow-arte-concert-celebrates-a-virtual-festival-summer-6873782.jpg', 'https://news.imz.at/imzfiles/636177-slideshow-arte-concert-celebrates-a-virtual-festival-summer-6873782.jpg', 300, 'event@event.com', 762343672, 'Stadthalle', 'Stadthallenstrasse 56, 1010 Wien', 'Concert'),
(3, 'Dance Party', 'safdgfdhhdgj sdfjsdfh sdfsiufjlsd sdf df dgfgjtudfgf safdgfdhhdgj sdfjsdfh sdfsiufjlsd sdf df dgfgjtudfgf safdgfdhhdgj sdfjsdfh sdfsiufjlsd sdf df dgfgjtudfgf', '2020-10-04', '18:08:00', 'https://www.freevector.com/uploads/vector/preview/14650/FreeVector-Dance-Party-Graphics.jpg', 'partypeople.at', 560, 'party@party.at', 55523245345, 'Kulturbühne Bludenz', 'Unterfelsstrasse 34, 6700 Bludenz', 'Dance'),
(5, 'Dance club part 2', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor i', '2020-11-18', '17:00:00', 'https://geminidjs.com/wp-content/uploads/2013/07/Club-Disco-Party-PPT-Backgrounds.jpg', 'partypeople.at', 567, 'party@party.at', 55523245345, 'Kulturbühne Bludenz', 'Strasse 45, 1010 Stadt', 'Dance'),
(6, 'bla bla', 'Lorem ipson balads sdsjkas cahaz sdkla sdkafkjsa dsj Lorem ipson balads sdsjkas cahaz sdkla sdkafkjsa dsj Lorem ipson balads sdsjkas cahaz sdkla sdkafkjsa dsj Lorem ipson balads sdsjkas cahaz sdkla sdkafkjsa dsj', '2021-07-27', '21:00:00', 'https://media.phillyvoice.com/media/images/06_013118_Daybreaker_Carroll.2e16d0ba.fill-735x490.jpg', 'partypeople.at', 234, 'party@party.at', 55523245345, 'Kulturbühne Bludenz', 'Studa 58, 6708 Brand', 'Concert'),
(7, 'Dark World', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor i', '2020-11-20', '18:00:00', 'https://www.youpod.de/_Resources/Persistent/f867d404013346cef6f1c189327597fabe9343f6/lul_6125_1.jpg', 'laientheater.at', 150, 'laien@theater.at', 5688333246, 'Laien Theater Innsbruck', 'Theaterstrasse 45, 6020 Innsbruck', 'Theater'),
(8, 'Little Women', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor i', '2020-12-28', '15:00:00', 'https://dramaturg.org/wp-content/uploads/2019/11/images-1.jpg', 'laientheater.at', 200, 'laien@theater.at', 5688333246, 'Kulturbühne Krems', 'Theaterstr. 44, 3056 Krems', 'Theater');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `event_info`
--
ALTER TABLE `event_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `event_info`
--
ALTER TABLE `event_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
