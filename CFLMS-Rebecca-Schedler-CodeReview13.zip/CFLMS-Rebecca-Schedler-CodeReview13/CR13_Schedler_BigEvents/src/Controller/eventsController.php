<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\ Route;
use Symfony\Component\ HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Entity\EventInfo;

class eventsController extends AbstractController
{
   /**
    * @Route("/", name="home")
    */
   public function showAction()
   {
        $events = $this->getDoctrine()->getRepository('App:EventInfo')->findAll();
        return $this->render('bigEvents/index.html.twig', array('events'=>$events));
   }

    /**
    * @Route("/create", name="create")
    */
   public  function createAction(Request $request)
   {
    $event = new EventInfo;
    $form = $this->createFormBuilder($event)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control','style'=>'margin-bottom:15px')))
        ->add('date', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
        ->add('time', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
        ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('event_url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('phonenumber', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('location_name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('eventtype', ChoiceType::class, array('choices'=>array('Concert'=>'Concert', 'Theater'=>'Theater', 'Dance'=>'Dance'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))   
        ->add('save', SubmitType::class, array('label'=> 'Post Event', 'attr' => array('class'=> 'btn-primary','style'=>'margin-bottom:15px')))
            ->getForm();
    $form->handleRequest($request);

    if($form->isSubmitted() && $form->isValid()){
        $name = $form['name']->getData();
        $description = $form['description']->getData();
        $date = $form['date']->getData();
        $time = $form['time']->getData();
        $image = $form['image']->getData();
        $event_url = $form['event_url']->getData();
        $capacity = $form['capacity']->getData();
        $email = $form['email']->getData();
        $phonenumber = $form['phonenumber']->getData();
        $location_name = $form['location_name']->getData();
        $address = $form['address']->getData();
        $eventtype = $form['eventtype']->getData();

        $event->setName($name);
        $event->setDescription($description);
        $event->setDate($date);
        $event->setTime($time);
        $event->setImage($image);
        $event->setEventURL($event_url);
        $event->setCapacity($capacity);
        $event->setEmail($email);
        $event->setPhonenumber($phonenumber);
        $event->setLocationName($location_name);
        $event->setAddress($address);
        $event->setEventtype($eventtype);
           
        $em = $this->getDoctrine()->getManager();
        $em->persist($event);
        $em->flush();
        $this->addFlash(
                   'notice',
                   'Event Added'
                   );
        return $this->redirectToRoute('home');
       }
     
    return  $this->render('bigEvents/create.html.twig', array('form' => $form->createView()));
   }

    /**
    * @Route("/details/{id}", name="details")
    */
    public  function detailsAction($id)
    {
        $event = $this->getDoctrine()->getRepository('App:EventInfo')->find($id);
        return $this->render('bigEvents/details.html.twig', array('event' => $event));
    }


    /**
    * @Route("/edit/{id}", name="edit")
    */
   public function editAction($id, Request $request)
   {
    $event = $this->getDoctrine()->getRepository('App:EventInfo')->find($id);
    
        $event->setName($event->getName());
        $event->setDescription($event->getDescription());
        $event->setDate($event->getDate());
        $event->setTime($event->getTime());
        $event->setImage($event->getImage());
        $event->setEventURL($event->getEventURL());
        $event->setCapacity($event->getCapacity());
        $event->setEmail($event->getEmail());
        $event->setPhonenumber($event->getPhonenumber());
        $event->setLocationName($event->getLocationName());
        $event->setAddress($event->getAddress());
        $event->setEventtype($event->getEventtype());


        $form = $this->createFormBuilder($event)
            ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
            ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
            ->add('date', DateTimeType::class, array('attr' => array('class'=> 'form-control','style'=>'margin-bottom:15px')))
            ->add('time', DateTimeType::class, array('attr' => array('class'=> 'form-control','style'=>'margin-bottom:15px')))
            ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('event_url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('phonenumber', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('location_name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('eventtype', ChoiceType::class, array('choices'=>array('Concert'=>'Concert', 'Theater'=>'Theater', 'Dance'=>'Dance'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
            ->add('save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-botton:15px')))
            ->getForm();

        $form->handleRequest($request);
           if($form->isSubmitted() && $form->isValid()){
            $name = $form['name']->getData();
            $description = $form['description']->getData();
            $date = $form['date']->getData();
            $time = $form['time']->getData();
            $image = $form['image']->getData();
            $event_url = $form['event_url']->getData();
            $capacity= $form['capacity']->getData();
            $email = $form['email']->getData();
            $phonenumber = $form['phonenumber']->getData();
            $location_name = $form['location_name']->getData();
            $address = $form['address']->getData();
            $eventtype = $form['eventtype']->getData();

            $em = $this->getDoctrine()->getManager();
            $todo = $em->getRepository('App:EventInfo')->find($id);
            $event->setName($name);
            $event->setDescription($description);
            $event->setDate($date);
            $event->setTime($time);
            $event->setImage($image);
            $event->setEventURL($event_url);
            $event->setCapacity($capacity);
            $event->setEmail($email);
            $event->setPhonenumber($phonenumber);
            $event->setLocationName($location_name);
            $event->setAddress($address);
            $event->setEventtype($eventtype);
           
            $em->flush();
               $this->addFlash(
                       'notice',
                       'Event Updated'
                       );
               return $this->redirectToRoute('home');
           }
           return $this->render('BigEvents/edit.html.twig', array('event' => $event, 'form' => $form->createView()));
   }

   /**
    * @Route("/delete/{id}", name="delete")
    */
    public function deleteAction($id){
        $em = $this->getDoctrine()->getManager();
        $event = $em->getRepository('App:EventInfo')->find($id);
        $em->remove($event);
        $em->flush();
            $this->addFlash(
           'notice',
           'Event Removed'
           );
    return $this->redirectToRoute('home');
}


}
